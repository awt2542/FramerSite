#!/usr/bin/env bash
cd "$(dirname "$0")"
touch /tmp/framerps.log
tail -f /tmp/framerps.log &
echo "//@include \"$(dirname "$0")/scripts/FramerPS.jsx\";" | ./psjs
kill $!
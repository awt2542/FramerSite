		window.FramerPS = window.FramerPS || {};
		window.FramerPS['Intro'] = [
	{
		"id": 46,
		"name": "Screen",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 320,
			"height": 568
		},
		"maskFrame": null,
		"image": null,
		"imageType": null,
		"children": [
			{
				"id": 74,
				"name": "PagingView",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 320,
					"height": 568
				},
				"maskFrame": null,
				"image": null,
				"imageType": null,
				"children": [
					{
						"id": 53,
						"name": "IntroView",
						"layerFrame": {
							"x": 0,
							"y": 0,
							"width": 320,
							"height": 568
						},
						"maskFrame": null,
						"image": {
							"path": "images/IntroView.png",
							"frame": {
								"x": 0,
								"y": 0,
								"width": 320,
								"height": 568
							}
						},
						"imageType": "png",
						"children": [
							{
								"id": 138,
								"name": "IntroButton",
								"layerFrame": {
									"x": 0,
									"y": 0,
									"width": 320,
									"height": 568
								},
								"maskFrame": null,
								"image": {
									"path": "images/IntroButton.png",
									"frame": {
										"x": 79,
										"y": 397,
										"width": 161,
										"height": 120
									}
								},
								"imageType": "png",
								"children": [
									
								],
								"modification": "1550039007"
							},
							{
								"id": 112,
								"name": "Logo",
								"layerFrame": {
									"x": 0,
									"y": 0,
									"width": 320,
									"height": 568
								},
								"maskFrame": null,
								"image": {
									"path": "images/Logo.png",
									"frame": {
										"x": 99,
										"y": 118,
										"width": 124,
										"height": 131
									}
								},
								"imageType": "png",
								"children": [
									
								],
								"modification": "1491634044"
							},
							{
								"id": 55,
								"name": "Gloss",
								"layerFrame": {
									"x": 0,
									"y": 0,
									"width": 320,
									"height": 568
								},
								"maskFrame": null,
								"image": {
									"path": "images/Gloss.png",
									"frame": {
										"x": 0,
										"y": 0,
										"width": 320,
										"height": 554
									}
								},
								"imageType": "png",
								"children": [
									
								],
								"modification": "1681292346"
							},
							{
								"id": 96,
								"name": "Text",
								"layerFrame": {
									"x": 0,
									"y": 0,
									"width": 320,
									"height": 568
								},
								"maskFrame": null,
								"image": {
									"path": "images/Text.png",
									"frame": {
										"x": 55,
										"y": 251,
										"width": 208,
										"height": 55
									}
								},
								"imageType": "png",
								"children": [
									
								],
								"modification": "187904984"
							}
						],
						"modification": "1525086829"
					}
				],
				"modification": "510813741"
			}
		],
		"modification": "298730859"
	}
]